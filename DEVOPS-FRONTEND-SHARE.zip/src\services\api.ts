import axios from 'axios';

/**
 * Base Axios instance configured for future Spring Boot API integration.
 * In Week 1, services use this or return local mock data directly.
 */
const api = axios.create({
  baseURL: ((import.meta as any).env?.VITE_API_BASE_URL) || 'http://localhost:8080/api/v1',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// Request interceptor (for future JWT or API keys)
api.interceptors.request.use(
  (config) => {
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor
api.interceptors.response.use(
  (response) => response,
  (error) => {
    return Promise.reject(error);
  }
);

export default api;
