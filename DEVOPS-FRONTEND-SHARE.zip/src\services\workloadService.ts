import { DeploymentItem, PodItem, ServiceItem } from '../types/workload';
import { mockDeployments, mockPods, mockServices } from '../data/mockWorkloads';

const delay = (ms: number = 100) => new Promise((resolve) => setTimeout(resolve, ms));

export const workloadService = {
  async getDeployments(namespace?: string): Promise<DeploymentItem[]> {
    await delay(120);
    if (namespace && namespace !== 'all') {
      return mockDeployments.filter((d) => d.namespace === namespace);
    }
    return [...mockDeployments];
  },

  async getPods(namespace?: string): Promise<PodItem[]> {
    await delay(120);
    if (namespace && namespace !== 'all') {
      return mockPods.filter((p) => p.namespace === namespace);
    }
    return [...mockPods];
  },

  async getServices(namespace?: string): Promise<ServiceItem[]> {
    await delay(120);
    if (namespace && namespace !== 'all') {
      return mockServices.filter((s) => s.namespace === namespace);
    }
    return [...mockServices];
  },

  async getWorkloadSummary(): Promise<{
    deployments: { total: number; healthy: number; degraded: number };
    pods: { total: number; running: number; crashloop: number };
    services: { total: number };
  }> {
    await delay(100);
    const healthyDep = mockDeployments.filter((d) => d.status === 'Healthy').length;
    const degradedDep = mockDeployments.filter((d) => d.status !== 'Healthy').length;
    const runningPods = mockPods.filter((p) => p.status === 'Running').length;
    const crashPods = mockPods.filter((p) => p.status === 'CrashLoopBackOff').length;

    return {
      deployments: { total: mockDeployments.length, healthy: healthyDep, degraded: degradedDep },
      pods: { total: mockPods.length, running: runningPods, crashloop: crashPods },
      services: { total: mockServices.length },
    };
  },
};
