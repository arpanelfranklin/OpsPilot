import { ClusterInfo, NodeItem } from '../types/cluster';
import { MetricDataPoint, ActivityEvent } from '../types/metric';
import { mockClusterData, mockNodes } from '../data/mockCluster';
import { mockResourceMetrics, mockRecentActivities } from '../data/mockMetrics';

// Simulating async network delay to mirror future Spring Boot API behavior
const delay = (ms: number = 100) => new Promise((resolve) => setTimeout(resolve, ms));

export const clusterService = {
  async getClusterOverview(clusterKey: string = 'production-us-east'): Promise<ClusterInfo> {
    await delay(120);
    const data = mockClusterData[clusterKey] || mockClusterData['production-us-east'];
    return { ...data };
  },

  async getAllClusters(): Promise<{ id: string; name: string; environment: string }[]> {
    await delay(80);
    return Object.entries(mockClusterData).map(([key, c]) => ({
      id: key,
      name: c.name,
      environment: c.environment,
    }));
  },

  async getClusterNodes(): Promise<NodeItem[]> {
    await delay(150);
    return [...mockNodes];
  },

  async getResourceMetrics(): Promise<MetricDataPoint[]> {
    await delay(100);
    return [...mockResourceMetrics];
  },

  async getRecentActivities(): Promise<ActivityEvent[]> {
    await delay(100);
    return [...mockRecentActivities];
  },
};
