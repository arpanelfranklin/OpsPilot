import { Incident, IncidentSeverity, IncidentStatus } from '../types/incident';
import { mockIncidents } from '../data/mockIncidents';

const delay = (ms: number = 100) => new Promise((resolve) => setTimeout(resolve, ms));

export interface IncidentFilterParams {
  severity?: IncidentSeverity | 'ALL';
  status?: IncidentStatus | 'ALL';
  service?: string | 'ALL';
  search?: string;
}

export const incidentService = {
  async getIncidents(filters?: IncidentFilterParams): Promise<Incident[]> {
    await delay(120);
    let result = [...mockIncidents];

    if (filters) {
      if (filters.severity && filters.severity !== 'ALL') {
        result = result.filter((inc) => inc.severity === filters.severity);
      }
      if (filters.status && filters.status !== 'ALL') {
        result = result.filter((inc) => inc.status === filters.status);
      }
      if (filters.service && filters.service !== 'ALL') {
        result = result.filter((inc) => inc.service.toLowerCase().includes(filters.service!.toLowerCase()));
      }
      if (filters.search && filters.search.trim()) {
        const query = filters.search.toLowerCase();
        result = result.filter(
          (inc) =>
            inc.id.toLowerCase().includes(query) ||
            inc.service.toLowerCase().includes(query) ||
            inc.problem.toLowerCase().includes(query) ||
            inc.diagnosis.summary.toLowerCase().includes(query)
        );
      }
    }

    return result;
  },

  async getIncidentById(id: string): Promise<Incident | null> {
    await delay(100);
    const normalized = id.toUpperCase().startsWith('INC-') ? id.toUpperCase() : `INC-${id}`;
    const incident = mockIncidents.find(
      (inc) => inc.id.toUpperCase() === normalized || inc.numericId.toString() === id
    );
    return incident ? { ...incident } : null;
  },

  /**
   * Action simulation endpoints (Week 1 placeholder).
   * In Week 2, this will send requests to Spring Boot endpoint POST /api/v1/incidents/{id}/actions
   */
  async simulateRemediation(
    incidentId: string,
    action: 'analyze_again' | 'restart_deployment' | 'scale_deployment' | 'rollback'
  ): Promise<{ success: boolean; message: string; timestamp: string }> {
    await delay(300);
    return {
      success: true,
      message: `Action simulation [${action}] acknowledged for ${incidentId}. Backend integration will be connected in Week 2.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
  },
};
